<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>

<div id="pgc_773" style="height:18px;"><div id="virtualc_773" style="height:18px;" class="virtuals"><div class="allContent" style="width:999px;height:18px;"><div id="c_773" class="droppable" style="width:999px;height:18px;"><a id="ac_773" class="ascroll" style="top:-86px;"></a></div></div></div></div>
