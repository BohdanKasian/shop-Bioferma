<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
register_nav_menus( [
    'articles_menu' => 'Меню на остальных страницах',
    'materials_menu' => 'Меню на странице материалов',
    ]);