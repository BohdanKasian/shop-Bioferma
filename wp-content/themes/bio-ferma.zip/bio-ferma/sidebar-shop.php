<?php
if ( ! is_active_sidebar( 'shop' ) ) {
    return;
}
?>
<div class="wrapper-content">
<aside id="secondary" class="widget-area">
    <?php dynamic_sidebar( 'shop' ); ?>
</aside>
<!--#secondaryaasdqwdasd-->