<?php
if( ! defined('ABSPATH')){
    exit;
}
?>
<div class="mini-cart-content">
  <?php the_widget('WC_Widget_Cart', 'title=');?>
</div>