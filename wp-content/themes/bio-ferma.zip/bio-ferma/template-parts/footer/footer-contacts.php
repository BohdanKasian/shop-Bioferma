<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

$footer_copy = carbon_get_theme_option('bio-ferma-footer-copy'); ?>

<div id="pgc_570" style="height:381px;">
    <div id="virtualc_570" style="height:381px;" class="virtuals">
        <div class="allContent" style="width:999px;height:381px;">
            <div id="c_570" class="droppable" style="width:999px;height:381px;">
                <a id="ac_570" class="ascroll" style="top:-86px;"></a>
                <div class="bi irz" id="i571" style="z-index:66;top:32px;left:0px;">
                    <div class="irz scroll0">
                        <p><span style="font-weight: 900; font-size: 35px;"><span style="font-family: Roboto, sans-serif;"><span style="font-weight: 900;"><span style="color: #515151; font-weight: 100;">Наши контакты</span></span></span></span></p>
                    </div>
                </div>
                <div class="bi irz" id="i575" style="z-index:70;top:318px;left:1px;">
                    <div class="irz scroll0">
                        <p><span style="font-family: Roboto, sans-serif; font-size: 14px;"> <?php echo $footer_copy;?> </span></p></div></div><div class="bi irz" id="i576" style="z-index:71;top:309px;left:474px;"><div class="irz scroll0"><a href="tel:+38(068)737-55-47" class="links" style="color: rgb(81,81,81);"><span style="font-family: Roboto, sans-serif; font-size: 35px; font-weight: 100;">+38(068)737-55-47</span></a></div></div><div class="bi irz" id="i577" style="z-index:72;top:96px;left:0px;"><div class="irz scroll0"><p style="text-align: left;"><span style="font-family: Roboto, sans-serif; font-size: 25px; font-weight: 100;">Наш адрес:</span></p>
                        <p style="text-align: left;"><span style="font-family: Roboto, sans-serif; font-size: 17px; font-weight: 100;">Украина г.Черкассы</span></p>
                        <p style="text-align: left;"><span style="font-size: 17px;"><span style="font-family: Roboto, sans-serif;">ул. Чехова 9А</span></span></p></div></div><div class="bi irz" id="i578" style="z-index:73;top:185px;left:0px;"><div class="irz scroll0"><p style="text-align: left;"><span style="font-family: Roboto, sans-serif; font-size: 25px; font-weight: 100;">Наш телефон:</span></p>
                        <p style="text-align: left;">+38(068)737-55-47</p></div></div><div class="bi irz" id="i579" style="z-index:74;top:99px;left:197px;"><div class="irz scroll0"><p style="text-align: left;"><span style="font-family: Roboto, sans-serif; font-size: 25px; font-weight: 100;">Наш e-mail:</span></p>
                        <p style="text-align: left;">biofermaof@gmail.com</p></div></div><div class="bi" id="i580" style="top:8px;left:593px;z-index:20;"><img src="<?php echo get_template_directory_uri(); ?>/assets/files/block/s-pig-2.png@times=1490361324" width="300" height="277" alt="" title="" class="bl center"></div><div class="bi" id="i572" style="top:37px;left:268px;z-index:67;"><img src="<?php echo get_template_directory_uri(); ?>/assets/files/block/572-561-554-549-545-525-512-509-s-list.png@times=1517409774" width="46" height="35" alt="" title="" class="bl center"></div><div class="bi irz" id="i573" style="top:285px;left:0px;z-index:68;"><table class="tb wh100"><tr><td class="td"><div class="line" id="l573"></div></td></tr></table></div><div class="bi" id="i574" style="top:297px;left:858px;z-index:69;"><img src="<?php echo get_template_directory_uri(); ?>/assets/files/block/s-logo.png@times=1517409744" width="125" height="74" alt="" title="" class="bl center"></div><div class="bi" id="i581" style="top:58px;left:835px;z-index:80;"><img src="<?php echo get_template_directory_uri(); ?>/assets/files/block/s-pak-gt-1.png@times=1505215155" width="160" height="220" alt="" title="" class="bl center"></div><a href="https://www.instagram.com/bioferm2000/" class="nodec" target="_blank"><div class="bi" id="i1120" style="top:226px;left:387px;z-index:100;"><img src="<?php echo get_template_directory_uri(); ?>/assets/files/block/s-inst.png@times=1517410105" width="48" height="48" alt="" title="" class="bl center"></div></a><a href="https://www.facebook.com/bioferm2000/" class="nodec" target="_blank"><div class="bi" id="i1121" style="top:226px;left:457px;z-index:100;"><img src="<?php echo get_template_directory_uri(); ?>/assets/files/block/s-fb.png@times=1517410156" width="48" height="48" alt="" title="" class="bl center"></div></a>
            </div>
        </div>
    </div>
</div>
